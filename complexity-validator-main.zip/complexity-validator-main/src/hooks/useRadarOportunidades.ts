import { useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useClients } from './useClients';
import { useCompany } from '@/contexts/CompanyContext';
import { useAuth } from '@/contexts/AuthContext';
import { Client, TAX_REGIME_LABELS } from '@/types/database';
import { formatCurrency } from '@/lib/scoreCalculator';
import { toast } from 'sonner';

const DEFAULT_BASE_COST = 350;
const DEFAULT_COMPLEXITY_FACTOR = 5;
const DEFAULT_TARGET_MARGIN = 0.30;

export interface OfficeSettings {
  id?: string;
  company_id: string;
  base_cost_per_client: number;
  complexity_cost_factor: number;
  target_margin: number;
}

export interface RadarClientData {
  client: Client;
  estimatedCost: number;
  marginValue: number;
  marginPct: number;
  recommendedFee: number;
  opportunityScore: number;
  isNegativeMargin: boolean;
  isUnderpriced: boolean;
  isRecommendedAdjustment: boolean;
  segment: string;
}

export interface SegmentData {
  segment: string;
  clientCount: number;
  avgFee: number;
  avgComplexity: number;
  avgMarginPct: number;
  totalRevenue: number;
}

function getSegment(client: Client): string {
  const regime = TAX_REGIME_LABELS[client.tax_regime] || client.tax_regime;
  if ((client as any).is_ecommerce) return `E-commerce (${regime})`;
  if ((client as any).has_import_operations) return `Importação (${regime})`;
  if ((client as any).has_tax_substitution) return `ST (${regime})`;
  return regime;
}

export function useOfficeSettings() {
  const { company } = useCompany();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const settingsQuery = useQuery({
    queryKey: ['office-financial-settings', company?.id],
    queryFn: async () => {
      if (!company?.id) return null;
      const { data, error } = await supabase
        .from('office_financial_settings')
        .select('*')
        .eq('company_id', company.id)
        .maybeSingle();
      if (error) throw error;
      return data as OfficeSettings | null;
    },
    enabled: !!company?.id,
  });

  const upsertSettings = useMutation({
    mutationFn: async (settings: Partial<OfficeSettings>) => {
      if (!company?.id) throw new Error('No company');
      const { data, error } = await supabase
        .from('office_financial_settings')
        .upsert({
          company_id: company.id,
          base_cost_per_client: settings.base_cost_per_client ?? DEFAULT_BASE_COST,
          complexity_cost_factor: settings.complexity_cost_factor ?? DEFAULT_COMPLEXITY_FACTOR,
          target_margin: settings.target_margin ?? DEFAULT_TARGET_MARGIN,
        }, { onConflict: 'company_id' })
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['office-financial-settings'] });
      toast.success('Configurações salvas!');
    },
    onError: (e) => toast.error('Erro ao salvar: ' + e.message),
  });

  const settings: OfficeSettings = settingsQuery.data || {
    company_id: company?.id || '',
    base_cost_per_client: DEFAULT_BASE_COST,
    complexity_cost_factor: DEFAULT_COMPLEXITY_FACTOR,
    target_margin: DEFAULT_TARGET_MARGIN,
  };

  return { settings, isLoading: settingsQuery.isLoading, upsertSettings: upsertSettings.mutateAsync };
}

export function useRadarOportunidades() {
  const { clients, isLoading: clientsLoading } = useClients();
  const { settings, isLoading: settingsLoading } = useOfficeSettings();

  const isLoading = clientsLoading || settingsLoading;

  const radarData: RadarClientData[] = useMemo(() => {
    return clients.map(client => {
      const estimatedCost = settings.base_cost_per_client + (client.complexity_score * settings.complexity_cost_factor);
      const marginValue = client.current_fee - estimatedCost;
      const marginPct = client.current_fee > 0 ? marginValue / client.current_fee : -1;
      const recommendedFee = estimatedCost / (1 - settings.target_margin);
      const opportunityScore = Math.max(0, recommendedFee - client.current_fee) + (client.complexity_score * 2);
      const isNegativeMargin = marginValue < 0;
      const isUnderpriced = marginPct < settings.target_margin;
      const isRecommendedAdjustment = isUnderpriced && client.complexity_score >= 35;

      return {
        client,
        estimatedCost,
        marginValue,
        marginPct,
        recommendedFee,
        opportunityScore,
        isNegativeMargin,
        isUnderpriced,
        isRecommendedAdjustment,
        segment: getSegment(client),
      };
    });
  }, [clients, settings]);

  const negativeMarginClients = useMemo(() => radarData.filter(d => d.isNegativeMargin), [radarData]);
  const underpricedClients = useMemo(() => radarData.filter(d => d.isUnderpriced), [radarData]);
  const potentialIncrease = useMemo(() =>
    radarData.reduce((sum, d) => sum + Math.max(0, d.recommendedFee - d.client.current_fee), 0),
    [radarData]
  );
  const portfolioMargin = useMemo(() => {
    const totalRevenue = clients.reduce((s, c) => s + c.current_fee, 0);
    const totalCost = radarData.reduce((s, d) => s + d.estimatedCost, 0);
    return totalRevenue > 0 ? ((totalRevenue - totalCost) / totalRevenue) * 100 : 0;
  }, [clients, radarData]);

  const topAdjustments = useMemo(() =>
    [...radarData].filter(d => d.isUnderpriced).sort((a, b) => b.opportunityScore - a.opportunityScore).slice(0, 10),
    [radarData]
  );

  const topNegative = useMemo(() =>
    [...negativeMarginClients].sort((a, b) => a.marginValue - b.marginValue).slice(0, 10),
    [negativeMarginClients]
  );

  const segments: SegmentData[] = useMemo(() => {
    const map = new Map<string, RadarClientData[]>();
    radarData.forEach(d => {
      const arr = map.get(d.segment) || [];
      arr.push(d);
      map.set(d.segment, arr);
    });
    return Array.from(map.entries()).map(([segment, items]) => ({
      segment,
      clientCount: items.length,
      avgFee: items.reduce((s, i) => s + i.client.current_fee, 0) / items.length,
      avgComplexity: items.reduce((s, i) => s + i.client.complexity_score, 0) / items.length,
      avgMarginPct: items.reduce((s, i) => s + i.marginPct, 0) / items.length * 100,
      totalRevenue: items.reduce((s, i) => s + i.client.current_fee, 0),
    })).sort((a, b) => b.avgMarginPct - a.avgMarginPct);
  }, [radarData]);

  return {
    radarData,
    negativeMarginClients,
    underpricedClients,
    potentialIncrease,
    portfolioMargin,
    topAdjustments,
    topNegative,
    segments,
    isLoading,
    settings,
  };
}
