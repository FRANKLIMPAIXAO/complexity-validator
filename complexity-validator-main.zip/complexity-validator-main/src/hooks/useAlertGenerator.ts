import { useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useClients } from '@/hooks/useClients';
import { useEmployees, useEmployeeMetrics } from '@/hooks/useEmployees';
import { useNotificationContext } from '@/contexts/NotificationContext';

export const useAlertGenerator = () => {
  const { user } = useAuth();
  const { clients } = useClients();
  const { data: employees } = useEmployees();
  const { data: allMetrics } = useEmployeeMetrics();
  const { createNotification, notifications } = useNotificationContext();
  const hasGeneratedRef = useRef(false);

  // Check for underpriced clients
  const checkUnderpricedClients = useCallback(async () => {
    if (!clients || !user) return;

    const underpricedClients = clients.filter(c => c.is_underpriced);
    
    if (underpricedClients.length > 0) {
      const recentUnderpricingNotification = notifications.find(
        n => n.type === 'underpricing' && 
        new Date(n.created_at) > new Date(Date.now() - 24 * 60 * 60 * 1000)
      );

      if (!recentUnderpricingNotification) {
        await createNotification(
          'Clientes Subprecificados Detectados',
          `Você tem ${underpricedClients.length} cliente(s) com honorários abaixo do ideal. Revise a precificação para otimizar sua receita.`,
          'underpricing'
        );
      }
    }
  }, [clients, user, createNotification, notifications]);

  // Check for at-risk employees
  const checkAtRiskEmployees = useCallback(async () => {
    if (!employees || !allMetrics || !user) return;

    // Get latest metrics per employee
    const latestMetricsMap = new Map<string, typeof allMetrics[0]>();
    allMetrics.forEach(m => {
      const existing = latestMetricsMap.get(m.employee_id);
      if (!existing || 
          m.period_year > existing.period_year || 
          (m.period_year === existing.period_year && m.period_month > existing.period_month)) {
        latestMetricsMap.set(m.employee_id, m);
      }
    });

    const atRiskEmployees = employees.filter(e => {
      const latestMetrics = latestMetricsMap.get(e.id);
      return latestMetrics?.performance_level === 'risco_operacional' || 
             latestMetrics?.performance_level === 'atencao';
    });

    if (atRiskEmployees.length > 0) {
      const recentRiskNotification = notifications.find(
        n => n.type === 'employee_risk' && 
        new Date(n.created_at) > new Date(Date.now() - 24 * 60 * 60 * 1000)
      );

      if (!recentRiskNotification) {
        const riskCount = atRiskEmployees.filter(e => 
          latestMetricsMap.get(e.id)?.performance_level === 'risco_operacional'
        ).length;
        
        const attentionCount = atRiskEmployees.filter(e => 
          latestMetricsMap.get(e.id)?.performance_level === 'atencao'
        ).length;

        let message = '';
        if (riskCount > 0) {
          message += `${riskCount} colaborador(es) em risco operacional. `;
        }
        if (attentionCount > 0) {
          message += `${attentionCount} colaborador(es) precisam de atenção.`;
        }

        await createNotification(
          'Colaboradores Requerem Atenção',
          message.trim(),
          'employee_risk'
        );
      }
    }
  }, [employees, allMetrics, user, createNotification, notifications]);

  // Check for deadline alerts (goals)
  const checkDeadlines = useCallback(async () => {
    // This would check strategic goals deadlines
  }, []);

  // Run checks on mount and when data changes
  useEffect(() => {
    if (!user || hasGeneratedRef.current) return;
    
    const timer = setTimeout(() => {
      if ((clients?.length ?? 0) > 0 || (employees?.length ?? 0) > 0) {
        hasGeneratedRef.current = true;
        checkUnderpricedClients();
        checkAtRiskEmployees();
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [user, clients, employees, checkUnderpricedClients, checkAtRiskEmployees]);

  return {
    checkUnderpricedClients,
    checkAtRiskEmployees,
    checkDeadlines
  };
};
