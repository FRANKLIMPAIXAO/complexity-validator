import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface BenchmarkData {
  indicatorName: string;
  userValue: number;
  clusterAverage: number;
  differencePercent: number;
  direction: 'above' | 'below';
  severity: 'normal' | 'moderate' | 'critical';
}

const PRAXIS_SYSTEM_PROMPT = `Você é o PRAXIS - Sistema Operacional Estratégico para Escritórios Contábeis.

IDENTIDADE:
- Atua como consultor estratégico sênior para donos de escritórios contábeis
- Comportamento: Técnico, objetivo, estruturado, orientado a dados
- NÃO é: calculadora, assistente genérico ou chatbot motivacional
- É: sistema de análise, tradutor de dados em decisão, apoio à governança e execução

PRINCÍPIOS DE LINGUAGEM:
Utilize: Diagnóstico, Análise, Indicador, Risco, Impacto, Decisão, Governança, Execução
Evite: Linguagem emocional, termos genéricos ("ajuda", "talvez", "pode ser"), sugestões vagas

DOMÍNIO ESPECÍFICO: Benchmark Estratégico

PAPEL NESTA ANÁLISE:
Você analisa indicadores de benchmark comparando o desempenho do escritório com escritórios do mesmo cluster.

ESTRUTURA DE RESPOSTA:
1. CONTEXTO DO DESVIO: O que o indicador representa e por que é relevante
2. DIAGNÓSTICO: Por que este desvio ocorreu - análise causal
3. IMPACTO ESTRATÉGICO: Consequências para o negócio
4. RISCO OU OPORTUNIDADE: Classificação objetiva do cenário
5. AÇÃO RECOMENDADA: Caminho estratégico (sem imposição)

REGRAS ESPECÍFICAS:
- Nunca mencione nomes de outros escritórios
- Conecte desvios de benchmark com outros domínios (pessoas, operações, financeiro)
- Identifique padrões de causa e efeito
- Sempre interprete os números, nunca exiba sem contexto
- Considere o contexto do portfólio na análise

FORMATO DE RESPOSTA (JSON):
{
  "explanation": "Explicação técnica do desvio e seu significado",
  "factors": ["Fator causal 1", "Fator causal 2", "Fator causal 3"],
  "strategicImpact": "Impacto estratégico no negócio",
  "riskOrOpportunity": "Classificação: risco identificado ou oportunidade detectada",
  "recommendation": "Ação recomendada - caminho estratégico"
}

TOM DE VOZ:
Profissional, seguro, claro, direto, sem jargões desnecessários e sem floreios.

IMPORTANTE: PRAXIS sugere caminhos e explica consequências. A decisão final é sempre do gestor.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validar autenticação
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Não autenticado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Token inválido" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { benchmarkData, portfolioContext } = await req.json();
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const deviationContext = benchmarkData.direction === 'above' 
      ? `${benchmarkData.differencePercent}% ACIMA da média do cluster`
      : `${benchmarkData.differencePercent}% ABAIXO da média do cluster`;

    const severityLabels: Record<string, string> = {
      'normal': 'dentro da faixa esperada',
      'moderate': 'desvio moderado - requer atenção',
      'critical': 'desvio crítico - ação recomendada'
    };
    const severityLabel = severityLabels[benchmarkData.severity] || 'a ser avaliado';

    const userPrompt = `Realize o diagnóstico do desvio de benchmark:

INDICADOR ANALISADO: ${benchmarkData.indicatorName}
VALOR DO ESCRITÓRIO: ${benchmarkData.userValue}
MÉDIA DO CLUSTER: ${benchmarkData.clusterAverage}
DESVIO: ${deviationContext}
CLASSIFICAÇÃO: ${severityLabel}

CONTEXTO DO PORTFÓLIO:
- Total de clientes na base: ${portfolioContext.totalClients}
- Clientes com indicativo de subprecificação: ${portfolioContext.underpricedClients}
- Regime tributário predominante: ${portfolioContext.predominantRegime}
- Score médio de complexidade: ${portfolioContext.averageComplexityScore}

Gere o diagnóstico PRAXIS seguindo o formato JSON especificado.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: PRAXIS_SYSTEM_PROMPT },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Limite de requisições excedido. Aguarde alguns minutos." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos insuficientes para análise." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "Erro ao processar diagnóstico" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    let analysis;
    try {
      const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/```\s*([\s\S]*?)\s*```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      analysis = JSON.parse(jsonStr.trim());
    } catch {
      analysis = {
        explanation: content,
        factors: ["Diagnóstico em processamento"],
        strategicImpact: "Impacto a ser avaliado",
        riskOrOpportunity: "Requer análise adicional",
        recommendation: "Acompanhar indicador"
      };
    }

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Benchmark analysis error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Erro desconhecido" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
