import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Verificar autenticação
    const authHeader = req.headers.get('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Não autenticado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Cliente admin com service_role (bypassa RLS)
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Verificar usuário pelo token
    const token = authHeader.replace('Bearer ', '')
    const { data: claimsData, error: claimsError } = await supabaseAdmin.auth.getClaims(token)
    
    if (claimsError || !claimsData?.claims) {
      console.error('Claims error:', claimsError)
      return new Response(
        JSON.stringify({ error: 'Token inválido' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const userId = claimsData.claims.sub as string
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID não encontrado no token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Verificar se usuário já tem empresa
    const { data: existingProfile } = await supabaseAdmin
      .from('profiles')
      .select('company_id')
      .eq('id', userId)
      .single()

    if (existingProfile?.company_id) {
      return new Response(
        JSON.stringify({ error: 'Usuário já possui uma empresa cadastrada' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Obter dados da empresa do body
    const companyData = await req.json()
    console.log('Creating company with data:', companyData)

    // Validar campos obrigatórios
    if (!companyData.razao_social || !companyData.cnpj) {
      return new Response(
        JSON.stringify({ error: 'Razão social e CNPJ são obrigatórios' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Criar empresa usando service_role (bypassa RLS)
    const { data: company, error: insertError } = await supabaseAdmin
      .from('companies')
      .insert({
        razao_social: companyData.razao_social,
        nome_fantasia: companyData.nome_fantasia || null,
        cnpj: companyData.cnpj,
        tax_regime: companyData.tax_regime || 'simples',
        responsible_name: companyData.responsible_name || null,
        responsible_email: companyData.responsible_email || null,
        is_active: true,
      })
      .select()
      .single()

    if (insertError) {
      console.error('Insert error:', insertError)
      return new Response(
        JSON.stringify({ error: `Erro ao criar empresa: ${insertError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Company created:', company)

    // Atribuir role de admin ao usuário
    const { error: roleError } = await supabaseAdmin
      .from('user_roles')
      .insert({
        user_id: userId,
        company_id: company.id,
        role: 'admin',
      })

    if (roleError) {
      console.error('Role insert error:', roleError)
      // Tentar deletar a empresa criada se falhar ao atribuir role
      await supabaseAdmin.from('companies').delete().eq('id', company.id)
      return new Response(
        JSON.stringify({ error: `Erro ao atribuir role: ${roleError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Admin role assigned to user:', userId)

    // Criar planos padrão para a empresa
    const defaultPlans = [
      { name: 'Black', color: '#1F2937', description: 'Plano exclusivo com atendimento premium', is_default: false, sort_order: 0 },
      { name: 'Tradicional', color: '#3B82F6', description: 'Plano padrão com serviços essenciais', is_default: true, sort_order: 1 },
      { name: 'Premium', color: '#8B5CF6', description: 'Plano com serviços adicionais', is_default: false, sort_order: 2 },
      { name: 'Gold', color: '#F59E0B', description: 'Plano intermediário com benefícios especiais', is_default: false, sort_order: 3 },
      { name: 'Abertura', color: '#10B981', description: 'Plano para empresas em fase de abertura', is_default: false, sort_order: 4 },
    ]

    const { error: plansError } = await supabaseAdmin
      .from('client_plans')
      .insert(defaultPlans.map(plan => ({
        ...plan,
        company_id: company.id,
      })))

    if (plansError) {
      console.error('Plans insert error:', plansError)
      // Não falhar por isso, apenas logar
    } else {
      console.log('Default plans created for company')
    }

    // Atualizar profile do usuário com o company_id
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .update({ company_id: company.id })
      .eq('id', userId)

    if (profileError) {
      console.error('Profile update error:', profileError)
      // Não falhar por isso, mas logar
    }

    console.log('Profile updated with company_id')

    return new Response(
      JSON.stringify({ company }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ error: 'Erro interno do servidor' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
