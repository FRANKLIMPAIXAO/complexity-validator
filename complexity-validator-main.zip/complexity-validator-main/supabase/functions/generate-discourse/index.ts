import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type EmployeeData = {
  id: string;
  name: string;
  role: string;
  department: string;
  hire_date: string;
};

type MetricsData = {
  clients_served: number;
  avg_client_complexity: number;
  tasks_assigned: number;
  tasks_completed: number;
  tasks_on_time: number;
  tasks_rework: number;
  obligations_delivered: number;
  obligations_delayed: number;
  obligations_errors: number;
  performance_score: number;
  performance_level: string;
};

type FeedbackData = {
  id: string;
  rating: number;
  comment: string;
  created_at: string;
};

type DiscourseType =
  | 'reajuste_salarial'
  | 'feedback_desenvolvimento'
  | 'treinamento_direcionado'
  | 'alerta_atencao'
  | 'avaliacao_desligamento';

const PRAXIS_SYSTEM_PROMPT = `Você é o PRAXIS | Pessoas & Performance.

IDENTIDADE:
Seu papel é gerar discursos técnicos, claros e justificados para apoiar decisões de gestão de pessoas em escritórios contábeis, com base em dados objetivos.

PRINCÍPIOS FUNDAMENTAIS:
- Você NÃO cria discursos emocionais
- Você NÃO impõe decisões
- Você NÃO julga pessoas
- Você analisa dados, explica cenários, estrutura conversas difíceis e dá base técnica para decisões justas

FONTES DE DADOS:
Baseie todas as análises nos seguintes indicadores:
- Quantidade de empresas atendidas
- Complexidade média dos clientes atendidos
- Percentual de tarefas entregues no prazo
- Volume de retrabalho ou correções
- Obrigações acessórias entregues no prazo
- Incidentes ou erros registrados
- Feedback de clientes
- Histórico de alertas operacionais
- Score de performance

ESTRUTURA DO DISCURSO:
1. Contexto objetivo
2. Diagnóstico técnico
3. Evidências (dados concretos)
4. Impacto operacional
5. Direcionamento estratégico
6. Próximo passo sugerido

REGRAS DE ÉTICA E GOVERNANÇA:
- Nunca utilizar linguagem acusatória
- Nunca expor comparações com outros colaboradores
- Nunca sugerir punição automática
- Sempre tratar desligamento como última alternativa
- Manter tom profissional e respeitoso

TOM DE VOZ:
Profissional, seguro, claro, direto, técnico. Sem jargões desnecessários e sem floreios.

IMPORTANTE: PRAXIS apoia decisões justas, técnicas e sustentáveis. A decisão final é sempre do gestor.`;

const DISCOURSE_PROMPTS: Record<DiscourseType, string> = {
  reajuste_salarial: `Gere um discurso para REAJUSTE SALARIAL.

CONTEXTO: Este discurso deve ser gerado quando o colaborador apresentar:
- Alto desempenho consistente
- Entregas no prazo acima da média
- Baixo retrabalho
- Feedback positivo recorrente

ESTRUTURA DO DISCURSO:
"Com base na análise de desempenho, identificamos que sua entrega está acima do padrão esperado para a função.

Os principais indicadores que sustentam essa avaliação são:
- [INDICADOR 1 - específico com número]
- [INDICADOR 2 - específico com número]
- [INDICADOR 3 - específico com número]

Esse nível de performance gera impacto positivo direto na qualidade do atendimento, previsibilidade operacional e redução de riscos.

Diante desse cenário, recomendamos a revisão de faixa salarial como reconhecimento técnico e estratégico."

Gere o discurso personalizado com base nos dados do colaborador.`,

  feedback_desenvolvimento: `Gere um discurso para FEEDBACK DE DESENVOLVIMENTO.

CONTEXTO: Este discurso deve ser gerado quando o desempenho for adequado ou em atenção.

ESTRUTURA DO DISCURSO:
"A análise dos indicadores mostra que sua performance está dentro do esperado, porém com pontos claros de melhoria.

Os fatores que mais impactam esse resultado hoje são:
- [FATOR 1 - específico]
- [FATOR 2 - específico]

Esses pontos não representam falha, mas oportunidades objetivas de desenvolvimento.

A recomendação é estruturar um plano de melhoria focado em [FOCO PRINCIPAL], com acompanhamento periódico."

Gere o discurso personalizado com base nos dados do colaborador.`,

  treinamento_direcionado: `Gere um discurso para TREINAMENTO DIRECIONADO.

CONTEXTO: Este discurso deve ser gerado quando houver padrão de erro, retrabalho ou dificuldade recorrente.

ESTRUTURA DO DISCURSO:
"A análise operacional identificou padrões recorrentes que indicam necessidade de reforço técnico.

Os indicadores que sustentam essa recomendação são:
- [INDICADOR 1 - específico com número]
- [INDICADOR 2 - específico com número]

Recomendamos treinamento direcionado em [TEMA ESPECÍFICO], com foco em redução de erros, aumento de eficiência e ganho de previsibilidade."

Gere o discurso personalizado com base nos dados do colaborador.`,

  alerta_atencao: `Gere um discurso de ALERTA (Zona de Atenção).

CONTEXTO: Este discurso deve ser gerado quando houver risco operacional crescente.

ESTRUTURA DO DISCURSO:
"Os indicadores atuais apontam um desvio relevante no padrão de entrega esperado para a função.

Os principais pontos de atenção são:
- [INDICADOR 1 - específico com número]
- [INDICADOR 2 - específico com número]

Esse cenário gera risco de impacto operacional e aumento de retrabalho.

Recomenda-se feedback estruturado imediato e definição de plano corretivo com prazo e acompanhamento."

Gere o discurso personalizado com base nos dados do colaborador.`,

  avaliacao_desligamento: `Gere um discurso para AVALIAÇÃO DE DESLIGAMENTO.

CONTEXTO CRÍTICO: Este discurso deve ser gerado SOMENTE quando:
- O colaborador estiver em risco operacional recorrente
- Planos corretivos anteriores não surtiram efeito
- Houver impacto direto no time ou nos clientes

ESTRUTURA DO DISCURSO:
"A análise histórica de desempenho demonstra persistência de desvios relevantes, mesmo após ações corretivas.

Os principais indicadores que sustentam essa avaliação são:
- [INDICADOR 1 - específico com número]
- [INDICADOR 2 - específico com número]
- [INDICADOR 3 - específico com número]

Esse cenário indica desalinhamento estrutural entre a função e a entrega exigida, com impacto operacional contínuo.

Recomenda-se avaliação de desligamento como decisão estratégica, visando preservação da qualidade, previsibilidade e equilíbrio da equipe."

IMPORTANTE: Mantenha tom profissional e respeitoso. Esta é uma recomendação técnica, não uma sentença.

Gere o discurso personalizado com base nos dados do colaborador.`
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { employee, metrics, feedback, discourseType } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const avgFeedback = feedback?.length > 0
      ? feedback.reduce((sum: number, f: { rating: number }) => sum + f.rating, 0) / feedback.length
      : null;

    const completionRate = metrics?.tasks_assigned > 0 
      ? ((metrics.tasks_completed / metrics.tasks_assigned) * 100).toFixed(1)
      : 0;
    
    const onTimeRate = metrics?.tasks_completed > 0
      ? ((metrics.tasks_on_time / metrics.tasks_completed) * 100).toFixed(1)
      : 0;

    const reworkRate = metrics?.tasks_completed > 0
      ? ((metrics.tasks_rework / metrics.tasks_completed) * 100).toFixed(1)
      : 0;

    const delayRate = metrics?.obligations_delivered > 0
      ? ((metrics.obligations_delayed / metrics.obligations_delivered) * 100).toFixed(1)
      : 0;

    const discoursePrompt = DISCOURSE_PROMPTS[discourseType as DiscourseType] || DISCOURSE_PROMPTS.feedback_desenvolvimento;

    const userPrompt = `${discoursePrompt}

DADOS DO COLABORADOR:
- Nome: ${employee.name}
- Cargo: ${employee.role}
- Departamento: ${employee.department}
- Data de admissão: ${employee.hire_date}

INDICADORES DE PERFORMANCE:
- Clientes atendidos: ${metrics?.clients_served || 0}
- Complexidade média dos clientes: ${metrics?.avg_client_complexity?.toFixed(1) || 'N/A'}
- Taxa de conclusão de tarefas: ${completionRate}% (${metrics?.tasks_completed || 0}/${metrics?.tasks_assigned || 0})
- Taxa de pontualidade: ${onTimeRate}% (${metrics?.tasks_on_time || 0} no prazo)
- Taxa de retrabalho: ${reworkRate}% (${metrics?.tasks_rework || 0} ocorrências)
- Obrigações entregues: ${metrics?.obligations_delivered || 0}
- Obrigações em atraso: ${delayRate}% (${metrics?.obligations_delayed || 0})
- Erros identificados: ${metrics?.obligations_errors || 0}
- Score de performance: ${metrics?.performance_score || 0}/100
- Classificação: ${metrics?.performance_level || 'não avaliado'}

FEEDBACK:
- Média de avaliações: ${avgFeedback?.toFixed(1) || 'Sem avaliações'}/5
- Total de feedbacks: ${feedback?.length || 0}

Gere o discurso estruturado seguindo o modelo especificado. Retorne em formato JSON:
{
  "title": "Título do discurso",
  "context": "Contexto objetivo",
  "diagnosis": "Diagnóstico técnico",
  "indicators": ["Indicador 1 com valor", "Indicador 2 com valor", "Indicador 3 com valor"],
  "impact": "Impacto operacional",
  "direction": "Direcionamento estratégico",
  "nextStep": "Próximo passo sugerido",
  "fullDiscourse": "Discurso completo formatado para apresentação ao colaborador"
}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: PRAXIS_SYSTEM_PROMPT },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Limite de requisições excedido. Aguarde alguns minutos." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos insuficientes para geração." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    let discourse;
    try {
      const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/```\s*([\s\S]*?)\s*```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      discourse = JSON.parse(jsonStr.trim());
    } catch {
      discourse = {
        title: "Discurso Gerado",
        context: "Análise de desempenho",
        diagnosis: content,
        indicators: [],
        impact: "A ser avaliado",
        direction: "Acompanhamento recomendado",
        nextStep: "Reunião de alinhamento",
        fullDiscourse: content
      };
    }

    return new Response(JSON.stringify(discourse), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Discourse generation error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Erro desconhecido"
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
