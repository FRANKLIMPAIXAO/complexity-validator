import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const { portfolioData, analysisType } = await req.json();

    let systemPrompt = "";
    let userPrompt = "";

    switch (analysisType) {
      case "portfolio":
        systemPrompt = `Você é um consultor estratégico especializado em escritórios de contabilidade no Brasil. 
Analise os dados do portfólio e forneça insights estratégicos em português brasileiro.
Seja direto, use dados concretos e forneça recomendações acionáveis.
Responda em formato markdown com seções claras.`;
        userPrompt = `Analise o portfólio deste escritório contábil e identifique padrões de subprecificação, riscos operacionais e oportunidades estratégicas.

Dados do portfólio:
- Total de clientes: ${portfolioData.totalClients}
- Honorário médio: R$ ${portfolioData.avgFee?.toFixed(2)}
- Score médio de complexidade: ${portfolioData.avgComplexity?.toFixed(1)}
- Clientes subprecificados: ${portfolioData.underpricedCount} (${portfolioData.underpricedPercentage?.toFixed(1)}%)
- Receita total mensal: R$ ${portfolioData.totalRevenue?.toFixed(2)}
- Custo operacional estimado: R$ ${portfolioData.totalCost?.toFixed(2)}
- Margem estimada: ${portfolioData.estimatedMargin?.toFixed(1)}%
- Distribuição por regime: Simples (${portfolioData.simpleCount}), Presumido (${portfolioData.presumidoCount}), Real (${portfolioData.realCount})
- Distribuição por complexidade: Básico (${portfolioData.basicCount}), Intermediário (${portfolioData.intermediarioCount}), Avançado (${portfolioData.avancadoCount}), Alto Risco (${portfolioData.altoRiscoCount}), Crítico (${portfolioData.criticoCount})
- Total de colaboradores: ${portfolioData.employeeCount}
- Custos do escritório: R$ ${portfolioData.officeExpenses?.toFixed(2)}

Forneça:
1. Resumo executivo (2-3 frases)
2. Pontos de atenção críticos
3. Oportunidades de melhoria de margem
4. Recomendações estratégicas`;
        break;

      case "growth":
        systemPrompt = `Você é um consultor de crescimento para escritórios de contabilidade no Brasil.
Analise a capacidade operacional e forneça projeções de crescimento realistas.
Responda em português brasileiro com dados concretos.`;
        userPrompt = `Analise a estratégia de crescimento proposta:

Dados atuais:
- Clientes atuais: ${portfolioData.currentClients}
- Colaboradores atuais: ${portfolioData.currentEmployees}
- Receita mensal atual: R$ ${portfolioData.currentRevenue?.toFixed(2)}
- Custo mensal atual: R$ ${portfolioData.currentCost?.toFixed(2)}

Projeção:
- Novos clientes desejados: ${portfolioData.targetNewClients}
- Honorário médio pretendido: R$ ${portfolioData.targetAvgFee?.toFixed(2)}
- Novas contratações planejadas: ${portfolioData.plannedHires}

Capacidade estimada: ${portfolioData.capacity} clientes por colaborador.

Forneça:
1. Análise da viabilidade
2. Projeções financeiras
3. Recomendações de contratação
4. Riscos e mitigações`;
        break;

      default:
        throw new Error("Invalid analysis type");
    }

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
        }),
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite de requisições excedido. Tente novamente em alguns minutos." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Créditos de IA insuficientes." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const text = await response.text();
      console.error("AI gateway error:", response.status, text);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "Não foi possível gerar a análise.";

    return new Response(
      JSON.stringify({ analysis: content }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("strategic-ai-analysis error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Erro desconhecido" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
