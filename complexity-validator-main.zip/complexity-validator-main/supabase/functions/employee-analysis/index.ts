import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const PRAXIS_SYSTEM_PROMPT = `Você é o PRAXIS - Sistema Operacional Estratégico para Escritórios Contábeis.

IDENTIDADE:
- Atua como consultor estratégico sênior para donos de escritórios contábeis
- Comportamento: Técnico, objetivo, estruturado, orientado a dados
- NÃO é: calculadora, assistente genérico ou chatbot motivacional
- É: sistema de análise, tradutor de dados em decisão, apoio à governança e execução

PRINCÍPIOS DE LINGUAGEM:
Utilize: Diagnóstico, Análise, Indicador, Risco, Impacto, Decisão, Governança, Execução
Evite: Linguagem emocional, termos genéricos ("ajuda", "talvez", "pode ser"), sugestões vagas

DOMÍNIO ESPECÍFICO: Pessoas & Performance

PAPEL NESTA ANÁLISE:
Você analisa dados de desempenho de colaboradores para apoiar decisões de gestão de pessoas.

ESTRUTURA DE RESPOSTA:
1. DIAGNÓSTICO: Análise objetiva do desempenho
2. FATORES DE IMPACTO: O que influenciou positiva e negativamente
3. RISCO OPERACIONAL: Nível de risco identificado
4. AÇÕES RECOMENDADAS: Sugestões concretas (nunca imposições)

REGRAS ESPECÍFICAS:
- Foco em desenvolvimento, não punição
- Linguagem técnica e respeitosa
- Nunca sugira desligamento automático
- Conecte performance individual com impacto operacional do escritório
- Sempre interprete os números, nunca exiba sem contexto

FORMATO DE RESPOSTA (JSON):
{
  "summary": "Diagnóstico objetivo do desempenho em 2-3 frases técnicas",
  "factors": ["Fator de impacto 1", "Fator de impacto 2", "Fator de impacto 3"],
  "recommendations": [
    {
      "type": "tipo_da_acao",
      "description": "Descrição objetiva da recomendação",
      "priority": "alta|media|baixa"
    }
  ],
  "riskLevel": "baixo|moderado|alto"
}

Tipos de ação disponíveis:
- melhoria_salarial
- reconhecimento
- feedback_periodico
- feedback_estruturado
- treinamento
- plano_desenvolvimento
- reavaliacao_funcao
- plano_corretivo

TOM DE VOZ:
Profissional, seguro, claro, direto, sem jargões desnecessários e sem floreios.

IMPORTANTE: PRAXIS sugere caminhos e explica consequências. A decisão final é sempre do gestor.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validar autenticação
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Não autenticado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Token inválido" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { employee, metrics, feedback } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const avgFeedback = feedback?.length > 0
      ? feedback.reduce((sum: number, f: any) => sum + f.rating, 0) / feedback.length
      : null;

    const completionRate = metrics?.tasks_assigned > 0 
      ? ((metrics.tasks_completed / metrics.tasks_assigned) * 100).toFixed(1)
      : 0;
    
    const onTimeRate = metrics?.tasks_completed > 0
      ? ((metrics.tasks_on_time / metrics.tasks_completed) * 100).toFixed(1)
      : 0;

    const userPrompt = `Realize o diagnóstico de desempenho do colaborador:

DADOS DO COLABORADOR:
- Nome: ${employee.name}
- Cargo: ${employee.role}
- Departamento: ${employee.department}
- Data de admissão: ${employee.hire_date}

INDICADORES DO PERÍODO:
- Clientes atendidos: ${metrics?.clients_served || 0}
- Complexidade média dos clientes: ${metrics?.avg_client_complexity?.toFixed(1) || 'N/A'}
- Demandas mensais processadas: ${metrics?.monthly_demands || 0}
- Taxa de conclusão de tarefas: ${completionRate}% (${metrics?.tasks_completed || 0}/${metrics?.tasks_assigned || 0})
- Taxa de pontualidade: ${onTimeRate}% (${metrics?.tasks_on_time || 0} no prazo)
- Índice de retrabalho: ${metrics?.tasks_rework || 0} ocorrências
- Obrigações entregues: ${metrics?.obligations_delivered || 0}
- Obrigações em atraso: ${metrics?.obligations_delayed || 0}
- Erros identificados: ${metrics?.obligations_errors || 0}
- Score de performance: ${metrics?.performance_score || 0}/100
- Classificação atual: ${metrics?.performance_level || 'não avaliado'}

AVALIAÇÕES:
- Média de avaliações: ${avgFeedback?.toFixed(1) || 'Sem avaliações'}/5
- Total de feedbacks registrados: ${feedback?.length || 0}

Gere o diagnóstico PRAXIS seguindo o formato JSON especificado.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: PRAXIS_SYSTEM_PROMPT },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Limite de requisições excedido. Aguarde alguns minutos." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos insuficientes para análise." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    let analysis;
    try {
      const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/```\s*([\s\S]*?)\s*```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      analysis = JSON.parse(jsonStr.trim());
    } catch {
      analysis = {
        summary: content,
        factors: ["Diagnóstico em processamento"],
        recommendations: [],
        riskLevel: "moderado"
      };
    }

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Employee analysis error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Erro desconhecido"
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
