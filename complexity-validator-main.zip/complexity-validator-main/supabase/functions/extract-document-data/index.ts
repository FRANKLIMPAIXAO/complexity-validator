import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify the caller's JWT
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub;

    const { documentId } = await req.json();
    
    if (!documentId) {
      throw new Error("Document ID is required");
    }

    console.log("Starting extraction for document:", documentId, "by user:", userId);

    // Use service role for actual operations
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get document info
    const { data: doc, error: docError } = await supabase
      .from("documents")
      .select("*, monthly_competences!inner(id, company_id)")
      .eq("id", documentId)
      .single();

    if (docError || !doc) {
      console.error("Document not found:", docError);
      throw new Error("Document not found");
    }

    // Verify the user belongs to the same company as the document
    const { data: userProfile } = await supabase
      .from("profiles")
      .select("company_id")
      .eq("id", userId)
      .single();

    if (!userProfile || userProfile.company_id !== doc.company_id) {
      return new Response(JSON.stringify({ error: 'Forbidden: you do not have access to this document' }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("Document found:", doc.file_name, "Type:", doc.document_type);

    // Download PDF from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("company-documents")
      .download(doc.file_path);

    if (downloadError || !fileData) {
      console.error("Error downloading file:", downloadError);
      throw new Error("Error downloading document from storage");
    }

    console.log("File downloaded, size:", fileData.size);

    // Convert to base64
    const arrayBuffer = await fileData.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    const binaryString = Array.from(uint8Array, byte => String.fromCharCode(byte)).join('');
    const base64Data = btoa(binaryString);

    console.log("File converted to base64");

    // Build extraction prompt based on document type
    let extractionPrompt = "";
    let expectedFields: string[] = [];

    if (doc.document_type === "folha_pagamento") {
      expectedFields = ["company_name", "cnpj", "employees_count", "total_payroll", "total_charges", "hires_count", "terminations_count"];
      extractionPrompt = `Analise este documento de Folha de Pagamento e extraia os seguintes dados:
- company_name: razão social ou nome fantasia da empresa (procure no cabeçalho do documento)
- cnpj: CNPJ da empresa no formato XX.XXX.XXX/XXXX-XX
- employees_count: número total de funcionários/colaboradores listados
- total_payroll: valor total da folha de pagamento (soma de todos os salários brutos)
- total_charges: total de encargos (INSS, FGTS, etc)
- hires_count: número de admissões no período (se mencionado, senão 0)
- terminations_count: número de demissões/desligamentos no período (se mencionado, senão 0)

IMPORTANTE: Retorne APENAS um objeto JSON válido com estes campos. Se não encontrar algum dado, use 0 para números e "" para texto.
Exemplo de resposta esperada:
{"company_name": "Empresa XYZ Ltda", "cnpj": "12.345.678/0001-90", "employees_count": 15, "total_payroll": 45000.00, "total_charges": 12500.00, "hires_count": 2, "terminations_count": 1}`;
    } else if (doc.document_type === "pgdas") {
      expectedFields = ["company_name", "cnpj", "period_revenue", "accumulated_revenue", "simples_anexo", "das_value"];
      extractionPrompt = `Analise este documento PGDAS (Programa Gerador do Documento de Arrecadação do Simples Nacional) e extraia:
- company_name: razão social ou nome fantasia da empresa
- cnpj: CNPJ da empresa no formato XX.XXX.XXX/XXXX-XX
- period_revenue: receita bruta do período de apuração
- accumulated_revenue: receita bruta acumulada nos últimos 12 meses (RBT12)
- simples_anexo: anexo do Simples Nacional aplicável (ex: "Anexo III", "Anexo V")
- das_value: valor do DAS a pagar

IMPORTANTE: Retorne APENAS um objeto JSON válido. Se não encontrar algum dado, use 0 para números e "" para texto.
Exemplo: {"company_name": "Empresa XYZ Ltda", "cnpj": "12.345.678/0001-90", "period_revenue": 50000.00, "accumulated_revenue": 600000.00, "simples_anexo": "Anexo III", "das_value": 5000.00}`;
    } else if (doc.document_type === "balancete") {
      expectedFields = ["company_name", "cnpj", "total_assets", "total_liabilities", "net_equity", "net_revenue", "net_profit"];
      extractionPrompt = `Analise este Balancete Contábil e extraia:
- company_name: razão social ou nome fantasia da empresa
- cnpj: CNPJ da empresa no formato XX.XXX.XXX/XXXX-XX
- total_assets: total do ativo
- total_liabilities: total do passivo
- net_equity: patrimônio líquido
- net_revenue: receita líquida
- net_profit: lucro/prejuízo líquido

Retorne APENAS um objeto JSON válido. Use 0 para valores não encontrados e "" para texto.`;
    } else {
      extractionPrompt = `Analise este documento e extraia todas as informações relevantes como números, valores monetários, datas e dados importantes. Inclua company_name (nome da empresa) e cnpj se encontrados. Retorne um objeto JSON com os dados encontrados.`;
    }

    // Call Lovable AI (Gemini) for extraction
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY not configured");
    }

    console.log("Calling Lovable AI for extraction...");

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: extractionPrompt
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:application/pdf;base64,${base64Data}`
                }
              }
            ]
          }
        ],
        temperature: 0.1,
        max_tokens: 2000,
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error("AI API error:", aiResponse.status, errorText);
      throw new Error(`AI API error: ${aiResponse.status}`);
    }

    const aiResult = await aiResponse.json();
    console.log("AI response received");

    // Parse the AI response
    const aiContent = aiResult.choices?.[0]?.message?.content || "";
    console.log("AI content:", aiContent);

    // Extract JSON from the response
    let extractedData: Record<string, unknown> = {};
    try {
      // Try to find JSON in the response
      const jsonMatch = aiContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        extractedData = JSON.parse(jsonMatch[0]);
        console.log("Extracted data:", extractedData);
      } else {
        console.error("No JSON found in AI response");
        throw new Error("No JSON found in AI response");
      }
    } catch (parseError) {
      console.error("Error parsing AI response:", parseError);
      if (doc.document_type === "folha_pagamento") {
        extractedData = { company_name: "", cnpj: "", employees_count: 0, total_payroll: 0, total_charges: 0, hires_count: 0, terminations_count: 0 };
      } else if (doc.document_type === "pgdas") {
        extractedData = { company_name: "", cnpj: "", period_revenue: 0, accumulated_revenue: 0, simples_anexo: "", das_value: 0 };
      } else {
        extractedData = {};
      }
    }

    // Calculate confidence based on how many expected fields were found
    let confidence = 85;
    if (expectedFields.length > 0) {
      const foundFields = expectedFields.filter(field => 
        extractedData[field] !== undefined && extractedData[field] !== 0 && extractedData[field] !== ""
      );
      confidence = Math.round((foundFields.length / expectedFields.length) * 100);
    }

    console.log("Extraction confidence:", confidence);

    // ========= CREATE OR UPDATE CLIENT =========
    const extractedCompanyName = String(extractedData.company_name || "").trim();
    const extractedCnpj = String(extractedData.cnpj || "").trim();
    
    const uploadedBy = doc.uploaded_by;
    let clientId: string | null = null;
    let clientAction: "created" | "updated" | null = null;

    if (extractedCnpj && uploadedBy) {
      console.log("Processing client with CNPJ:", extractedCnpj);
      
      const { data: existingClient } = await supabase
        .from("clients")
        .select("*")
        .eq("user_id", uploadedBy)
        .eq("cnpj", extractedCnpj)
        .single();

      const employeesCount = Number(extractedData.employees_count) || 0;
      const monthlyHires = Number(extractedData.hires_count) || 0;
      const monthlyTerminations = Number(extractedData.terminations_count) || 0;
      
      const calculateComplexity = (employees: number, hires: number, terminations: number) => {
        let score = 0;
        if (employees <= 5) score += 5;
        else if (employees <= 15) score += 10;
        else if (employees <= 30) score += 15;
        else if (employees <= 50) score += 20;
        else score += 25;
        const movement = hires + terminations;
        if (movement <= 2) score += 3;
        else if (movement <= 5) score += 7;
        else if (movement <= 10) score += 11;
        else score += 15;
        return score;
      };
      
      const getComplexityLevel = (score: number): string => {
        if (score <= 20) return "basico";
        if (score <= 35) return "intermediario";
        if (score <= 50) return "avancado";
        if (score <= 70) return "alto_risco";
        return "critico";
      };
      
      const complexityScore = calculateComplexity(employeesCount, monthlyHires, monthlyTerminations);
      const complexityLevel = getComplexityLevel(complexityScore);
      
      if (existingClient) {
        console.log("Updating existing client:", existingClient.id);
        const { error: updateClientError } = await supabase
          .from("clients")
          .update({
            employees_count: employeesCount,
            monthly_hires: monthlyHires,
            monthly_terminations: monthlyTerminations,
            complexity_score: complexityScore,
            complexity_level: complexityLevel,
            updated_at: new Date().toISOString()
          })
          .eq("id", existingClient.id);
        
        if (updateClientError) {
          console.error("Error updating client:", updateClientError);
        } else {
          clientId = existingClient.id;
          clientAction = "updated";
        }
      } else {
        console.log("Creating new client with name:", extractedCompanyName || "Cliente (CNPJ: " + extractedCnpj + ")");
        const newClientData = {
          user_id: uploadedBy,
          name: extractedCompanyName || `Cliente (${extractedCnpj})`,
          cnpj: extractedCnpj,
          tax_regime: "simples" as const,
          monthly_entries: 0,
          monthly_revenue: 0,
          employees_count: employeesCount,
          monthly_hires: monthlyHires,
          monthly_terminations: monthlyTerminations,
          current_fee: 0,
          complexity_score: complexityScore,
          complexity_level: complexityLevel,
          is_underpriced: false
        };
        
        const { data: newClient, error: insertClientError } = await supabase
          .from("clients")
          .insert(newClientData)
          .select("id")
          .single();
        
        if (insertClientError) {
          console.error("Error creating client:", insertClientError);
        } else {
          clientId = newClient?.id || null;
          clientAction = "created";
        }
      }
    }

    // Update document with extracted data
    const { error: updateError } = await supabase
      .from("documents")
      .update({ 
        status: "extracted", 
        extracted_data: extractedData, 
        extraction_confidence: confidence 
      })
      .eq("id", documentId);

    if (updateError) {
      console.error("Error updating document:", updateError);
      throw updateError;
    }

    // Also update monthly_analyses with the extracted data
    const companyId = doc.company_id;
    const competenceId = doc.competence_id;

    const { data: existingAnalysis } = await supabase
      .from("monthly_analyses")
      .select("id")
      .eq("company_id", companyId)
      .eq("competence_id", competenceId)
      .single();

    const analysisUpdate: Record<string, unknown> = {};
    
    if (doc.document_type === "folha_pagamento") {
      if (extractedData.employees_count) analysisUpdate.employees_count = extractedData.employees_count;
      if (extractedData.total_payroll) analysisUpdate.total_payroll = extractedData.total_payroll;
      if (extractedData.total_charges) analysisUpdate.total_charges = extractedData.total_charges;
      if (extractedData.hires_count) analysisUpdate.hires_count = extractedData.hires_count;
      if (extractedData.terminations_count) analysisUpdate.terminations_count = extractedData.terminations_count;
      analysisUpdate.payroll_validated = false;
    } else if (doc.document_type === "pgdas") {
      if (extractedData.period_revenue) analysisUpdate.period_revenue = extractedData.period_revenue;
      if (extractedData.accumulated_revenue) analysisUpdate.accumulated_revenue = extractedData.accumulated_revenue;
      if (extractedData.simples_anexo) analysisUpdate.simples_anexo = extractedData.simples_anexo;
      if (extractedData.das_value) analysisUpdate.das_value = extractedData.das_value;
      analysisUpdate.pgdas_validated = false;
    }

    if (Object.keys(analysisUpdate).length > 0) {
      if (existingAnalysis) {
        await supabase.from("monthly_analyses").update(analysisUpdate).eq("id", existingAnalysis.id);
      } else {
        await supabase.from("monthly_analyses").insert({ company_id: companyId, competence_id: competenceId, ...analysisUpdate });
      }
    }

    return new Response(JSON.stringify({ 
      success: true, 
      extractedData,
      confidence,
      client: clientId ? { id: clientId, action: clientAction } : null
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Extraction error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    
    try {
      const { documentId } = await req.clone().json();
      if (documentId) {
        const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
        const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const supabase = createClient(supabaseUrl, supabaseKey);
        await supabase.from("documents").update({ status: "error", extraction_error: errorMessage }).eq("id", documentId);
      }
    } catch {
      // Ignore
    }
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
